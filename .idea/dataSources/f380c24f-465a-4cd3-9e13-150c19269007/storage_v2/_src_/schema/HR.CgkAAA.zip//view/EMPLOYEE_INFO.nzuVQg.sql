create view EMPLOYEE_INFO as
select last_name || ' ' ||first_name
as full_name, lower(email ||'@gmail.com') as Email
from employees
/

