create package wwv_flow_css as

-- current version string for the CSS files
c_apex_version constant varchar2(10) := '_4_0';
--
--==============================================================================
-- Adds the style tag to load a css library.
-- If a library has already been added, it will not be added a second time.
-- Parameter:
--   p_name:           has to be specified without .js
--   p_directory:      has to have a trailing slash
--   p_version:        version identifier which should be added to the library name (optional)
--   p_skip_extension: if true the extension .css is NOT added (optional)
--==============================================================================
procedure add_file (
    p_name           in varchar2,
    p_directory      in varchar2 default wwv_flow.g_image_prefix||'css/',
    p_version        in varchar2 default c_apex_version,
    p_skip_extension in boolean  default false );
--
--==============================================================================
-- Adds a CSS style snippet which is included inline into the HTML output
-- eg. You can use this procedure to add new css style declarations.
--
-- If an entry with the same key exits it will be ignored.
-- If p_key is null the snippet will always be added.
--
-- Parameter:
--   p_style: CSS style snippet. eg: #test { color:#fff }
--   p_key:   identifier for the style snippet. If specified and a style snippet with
--            the same name has already been added the new style snippet will be ignored.
--==============================================================================
procedure add (
    p_css in varchar2,
    p_key in varchar2 default null );
--
--
-- *****************************************************************************
--  I N T E R N A L   A P I
-- *****************************************************************************
--
--==============================================================================
-- Emits CSS style snippets which have been added to the internal buffer.
--==============================================================================
procedure emit;
--
--==============================================================================
-- Returns the standard CSS files of APEX. If wwv_flow.g_include_apex_css_js_yn
-- is set to no, nothing is returned
--==============================================================================
function get_standard_files return varchar2;
--
--==============================================================================
-- Adds a CSS style snippet into an internal buffer which is emitted by
-- the call to emit later in the page rendering.
--
-- If an entry with the same key exits it will be ignored.
-- If p_key is null the snippet will always be added.
--
-- Parameter:
--   p_style: CSS style snippet. eg: .test { color:#fff }
--   p_key:   identifier for the style snippet. If specified and a style snippet with
--            the same name has already been added the new style snippet will be ignored.
--   p_type:  name of the style type. eg: INLINE, LINK
--==============================================================================
procedure add (
    p_css  in varchar2,
    p_type in varchar2,
    p_key  in varchar2 default null );
--
--==============================================================================
-- Saves the buffered CSS code in the page/region cache table wwv_flow_page_code_cache.
-- If p_region_id is specified, only the CSS code for that region is saved.
--==============================================================================
procedure save_in_cache (
    p_page_cache_id in number,
    p_region_id     in number default null );
--
end wwv_flow_css;
/

