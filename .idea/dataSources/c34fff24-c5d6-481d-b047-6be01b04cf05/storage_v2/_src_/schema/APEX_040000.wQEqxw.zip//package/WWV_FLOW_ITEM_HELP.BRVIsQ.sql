create package wwv_flow_item_help
as

--==============================================================================
-- Shows the defined help text of an page item.
--==============================================================================
procedure show_help (
    p_item_id           in varchar2 default null,
    p_session           in varchar2 default null,
    p_close_button_name in varchar2 default 'Close',
    p_title_bgcolor     in varchar2 default '#cccccc;',
    p_page_bgcolor      in varchar2 default '#FFFFFF',
    p_output_format     in varchar2 default 'HTML' );

--==============================================================================
-- Shows the defined help text of a plug-in attribute.
--==============================================================================
procedure show_plugin_attribute_help (
    p_application_id     in number,
    p_builder_page_id    in number,
    p_session_id         in varchar2,
    p_plugin_type        in varchar2,
    p_plugin_name        in varchar2,
    p_attribute_scope    in varchar2,
    p_attribute_sequence in number,
    p_output_format      in varchar2 default 'JSON' );

end;
/

