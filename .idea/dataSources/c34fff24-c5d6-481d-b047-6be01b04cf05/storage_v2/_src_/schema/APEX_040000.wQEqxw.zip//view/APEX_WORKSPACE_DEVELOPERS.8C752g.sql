create view APEX_WORKSPACE_DEVELOPERS as
select "WORKSPACE_ID","WORKSPACE_NAME","FIRST_SCHEMA_PROVISIONED","USER_NAME","EMAIL","DATE_CREATED","DATE_LAST_UPDATED","AVAILABLE_SCHEMAS","IS_ADMIN","IS_APPLICATION_DEVELOPER"
from apex_workspace_apex_users
where is_application_developer = 'Yes'
/

comment on table APEX_WORKSPACE_DEVELOPERS is 'Application Express (APEX) developers, APEX users with privilege to develop applications'
/

comment on column APEX_WORKSPACE_DEVELOPERS.WORKSPACE_ID is 'Primary key that identifies the workspace'
/

comment on column APEX_WORKSPACE_DEVELOPERS.WORKSPACE_NAME is 'A work area mapped to one or more database schemas'
/

comment on column APEX_WORKSPACE_DEVELOPERS.FIRST_SCHEMA_PROVISIONED is 'The associated database schema identified when this workspace was created'
/

comment on column APEX_WORKSPACE_DEVELOPERS.USER_NAME is 'The APEX user name used to authenticate to an APEX web page or APEX application'
/

comment on column APEX_WORKSPACE_DEVELOPERS.EMAIL is 'The email associated with this APEX user'
/

comment on column APEX_WORKSPACE_DEVELOPERS.DATE_CREATED is 'The date the APEX user was created'
/

comment on column APEX_WORKSPACE_DEVELOPERS.DATE_LAST_UPDATED is 'The date the APEX user definition was last updated'
/

comment on column APEX_WORKSPACE_DEVELOPERS.AVAILABLE_SCHEMAS is 'The number of database schemas available to the workspace developer'
/

comment on column APEX_WORKSPACE_DEVELOPERS.IS_ADMIN is 'Identifies if the APEX user has APEX workspace administration privilege'
/

comment on column APEX_WORKSPACE_DEVELOPERS.IS_APPLICATION_DEVELOPER is 'Identifies if the APEX user has APEX application development privilege'
/

