create view APEX_WS_DATA_GRID_COL as
select
w.short_name                workspace,
a.id                        application_id,
a.name                      application_name,
ir.id                       interactive_report_id,
dg.id                       data_grid_id,
c.id                        column_id,
c.db_column_name            column_alias,
c.display_order             display_order,
(select name from wwv_flow_worksheet_col_groups where id = c.group_id) column_group,
c.group_id                  column_group_id,
c.report_label              report_label,
c.column_label              form_label,
c.column_link               ,
c.column_linktext           ,
c.column_link_attr          ,
c.column_link_checksum_type ,
--
decode(c.allow_sorting     ,'Y','Yes','N','No',c.allow_sorting     ) allow_sorting     ,
decode(c.allow_filtering   ,'Y','Yes','N','No',c.allow_filtering   ) allow_filtering   ,
decode(c.allow_highlighting   ,'Y','Yes','N','No',c.allow_highlighting) allow_highlighting,
decode(c.allow_ctrl_breaks ,'Y','Yes','N','No',c.allow_ctrl_breaks ) allow_ctrl_breaks ,
decode(c.allow_aggregations,'Y','Yes','N','No',c.allow_aggregations) allow_aggregations,
decode(c.allow_computations,'Y','Yes','N','No',c.allow_computations) allow_computations,
decode(c.allow_charting    ,'Y','Yes','N','No',c.allow_charting    ) allow_charting    ,
decode(c.allow_group_by    ,'Y','Yes','N','No',c.allow_group_by    ) allow_group_by    ,
decode(c.allow_hide        ,'Y','Yes','N','No',c.allow_hide        ) allow_hide        ,
--
c.column_type               ,
c.display_text_as           ,
c.heading_alignment         ,
c.column_alignment          ,
c.format_mask               ,
tz_dependent                ,
--
decode(c.rpt_show_filter_lov,
       'D','Default Based on Column Type',
       'S','Use Defined List of Values to Filter Exact Match',
       'C','Use Defined List of Values to Filter Word Contains',
       '1','Use Named List of Values to Filter Exact Match',
       '2','Use Named List of Values to Filter Word Contains',
       'N','None',
       c.rpt_show_filter_lov)
                            filter_lov_source,
c.rpt_filter_date_ranges    filter_date_ranges,
--
c.help_text                 ,
--
c.column_expr,
c.column_comment                component_comment,
--
c.created_on,
c.created_by,
c.updated_on,
c.updated_by
from wwv_flow_worksheet_columns c,
     wwv_flow_worksheets ir,
     wwv_flow_ws_websheet_attr dg,
     wwv_flow_ws_applications a,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = a.security_group_id) and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.is_apex$_schema = 'Y' and
      a.security_group_id = w.provisioning_company_id and
      a.security_group_id = c.security_group_id and
      a.security_group_id = dg.security_group_id and
      a.id = dg.ws_app_id and
      ir.id = dg.worksheet_id and
      ir.id = c.worksheet_id and
      dg.websheet_type = 'DATA' and
      w.provisioning_company_id != 0
/

comment on table APEX_WS_DATA_GRID_COL is 'Report column definitions for Websheet Data Grid columns'
/

comment on column APEX_WS_DATA_GRID_COL.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_WS_DATA_GRID_COL.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_WS_DATA_GRID_COL.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_WS_DATA_GRID_COL.INTERACTIVE_REPORT_ID is 'ID of the interactive report'
/

comment on column APEX_WS_DATA_GRID_COL.DATA_GRID_ID is 'ID of the Data Grid'
/

comment on column APEX_WS_DATA_GRID_COL.COLUMN_ID is 'ID of this column'
/

comment on column APEX_WS_DATA_GRID_COL.COLUMN_ALIAS is 'Database column name or expression to use in SQL query when displaying this data grid column'
/

comment on column APEX_WS_DATA_GRID_COL.DISPLAY_ORDER is 'Default display order of this column'
/

comment on column APEX_WS_DATA_GRID_COL.COLUMN_GROUP is 'Name of the column group for this column'
/

comment on column APEX_WS_DATA_GRID_COL.COLUMN_GROUP_ID is 'ID of the column group for this column'
/

comment on column APEX_WS_DATA_GRID_COL.REPORT_LABEL is 'Report heading label to use for this column'
/

comment on column APEX_WS_DATA_GRID_COL.FORM_LABEL is 'Single row view label to use for this column'
/

comment on column APEX_WS_DATA_GRID_COL.COLUMN_LINK is 'Optional link target for this column'
/

comment on column APEX_WS_DATA_GRID_COL.COLUMN_LINKTEXT is 'Text to display if a link is defined'
/

comment on column APEX_WS_DATA_GRID_COL.COLUMN_LINK_ATTR is 'Link attributes for the column link.  Displayed within the HTML "A" tag'
/

comment on column APEX_WS_DATA_GRID_COL.COLUMN_LINK_CHECKSUM_TYPE is 'An appropriate checksum when linking to protected pages'
/

comment on column APEX_WS_DATA_GRID_COL.ALLOW_SORTING is 'Determines whether to allow sorting for this column.'
/

comment on column APEX_WS_DATA_GRID_COL.ALLOW_FILTERING is 'Determines whether to allow filtering for this column.'
/

comment on column APEX_WS_DATA_GRID_COL.ALLOW_HIGHLIGHTING is 'Determines whether to allow highlighting for this column.'
/

comment on column APEX_WS_DATA_GRID_COL.ALLOW_CTRL_BREAKS is 'Determines whether to allow control breaks for this column.'
/

comment on column APEX_WS_DATA_GRID_COL.ALLOW_AGGREGATIONS is 'Determines whether to allow aggregations for this column.'
/

comment on column APEX_WS_DATA_GRID_COL.ALLOW_COMPUTATIONS is 'Determines whether to allow computations for this column.'
/

comment on column APEX_WS_DATA_GRID_COL.ALLOW_CHARTING is 'Determines whether to allow charting for this column.'
/

comment on column APEX_WS_DATA_GRID_COL.ALLOW_GROUP_BY is 'Determines whether to allow group by for this column.'
/

comment on column APEX_WS_DATA_GRID_COL.ALLOW_HIDE is 'Determines whether to allow hiding this column.'
/

comment on column APEX_WS_DATA_GRID_COL.COLUMN_TYPE is 'Type of data in this column'
/

comment on column APEX_WS_DATA_GRID_COL.DISPLAY_TEXT_AS is 'Format to display this column'
/

comment on column APEX_WS_DATA_GRID_COL.HEADING_ALIGNMENT is 'Horizontal alignment of this column''s report heading'
/

comment on column APEX_WS_DATA_GRID_COL.COLUMN_ALIGNMENT is 'Horizontal alignment of this column''s report data'
/

comment on column APEX_WS_DATA_GRID_COL.FORMAT_MASK is 'Format mask for this column'
/

comment on column APEX_WS_DATA_GRID_COL.TZ_DEPENDENT is 'Column is time zone dependent'
/

comment on column APEX_WS_DATA_GRID_COL.FILTER_LOV_SOURCE is 'Query used to retrieve a list of values for the interactive report.  Displayed in the column header dropdowns, and during filter and highlight creation.'
/

comment on column APEX_WS_DATA_GRID_COL.FILTER_DATE_RANGES is 'Determines the range of dates to display for filters on this column'
/

comment on column APEX_WS_DATA_GRID_COL.HELP_TEXT is 'Descriptive help text for this column, displayed when a user clicks on the column information icon'
/

comment on column APEX_WS_DATA_GRID_COL.COLUMN_EXPR is 'Attribute for internal use only'
/

comment on column APEX_WS_DATA_GRID_COL.COMPONENT_COMMENT is 'Developer Comment'
/

comment on column APEX_WS_DATA_GRID_COL.CREATED_ON is 'Auditing; date the record was created.'
/

comment on column APEX_WS_DATA_GRID_COL.CREATED_BY is 'Auditing; user that created the record.'
/

comment on column APEX_WS_DATA_GRID_COL.UPDATED_ON is 'Auditing; date the record was last modified.'
/

comment on column APEX_WS_DATA_GRID_COL.UPDATED_BY is 'Auditing; user that last modified the record.'
/

