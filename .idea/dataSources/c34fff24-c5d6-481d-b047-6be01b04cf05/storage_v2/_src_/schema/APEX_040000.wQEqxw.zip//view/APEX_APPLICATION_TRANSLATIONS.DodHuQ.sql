create view APEX_APPLICATION_TRANSLATIONS as
select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    t.NAME                           translatable_message,
    t.MESSAGE_LANGUAGE               language_code,
    --
    t.MESSAGE_TEXT                   message_text,
    t.LAST_UPDATED_BY                last_updated_by,
    t.LAST_UPDATED_ON                last_updated_on,
    t.MESSAGE_COMMENT                developer_comment,
    t.id                             translation_entry_id
from WWV_FLOW_MESSAGES$ t,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      f.id = t.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      /* keep this language map not exists */
      not exists (
        select 1 from wwv_flow_language_map
        where translation_flow_id = f.id) and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_APPLICATION_TRANSLATIONS is 'Identifies message primary language text and translated text'
/

comment on column APEX_APPLICATION_TRANSLATIONS.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_TRANSLATIONS.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_TRANSLATIONS.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_TRANSLATIONS.TRANSLATABLE_MESSAGE is 'Identifies the Message Name'
/

comment on column APEX_APPLICATION_TRANSLATIONS.LANGUAGE_CODE is 'Identifies the Language Code'
/

comment on column APEX_APPLICATION_TRANSLATIONS.MESSAGE_TEXT is 'Identifies the message text in the Language Code language'
/

comment on column APEX_APPLICATION_TRANSLATIONS.LAST_UPDATED_BY is 'APEX developer who made last update'
/

comment on column APEX_APPLICATION_TRANSLATIONS.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_TRANSLATIONS.DEVELOPER_COMMENT is 'Developer Comment'
/

comment on column APEX_APPLICATION_TRANSLATIONS.TRANSLATION_ENTRY_ID is 'Primary Key of this Translation Entry'
/

