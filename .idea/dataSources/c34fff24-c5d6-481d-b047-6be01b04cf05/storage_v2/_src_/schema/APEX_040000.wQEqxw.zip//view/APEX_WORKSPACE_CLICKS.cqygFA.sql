create view APEX_WORKSPACE_CLICKS as
select short_name                   workspace,
           category                     category,
           flow_user                    apex_user,
           clickdate                    clickdate,
           a.id                         click_id,
           ip                           clicker_ip,
           provisioning_company_id      workspace_id
      from (select clickdate, category, l.id, flow_user, ip, w.provisioning_company_id,
                   w.short_name, w.first_schema_provisioned
              from wwv_flow_clickthru_log$ l, wwv_flow_companies w
             where l.security_group_id = w.provisioning_company_id
            union all
            select clickdate, category, l.id, flow_user, ip, w.provisioning_company_id,
                   w.short_name, w.first_schema_provisioned
              from wwv_flow_clickthru_log2$ l, wwv_flow_companies w
             where l.security_group_id = w.provisioning_company_id
            ) a,
            wwv_flow_company_schemas s,
            (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
      where s.security_group_id = a.provisioning_company_id
        and a.first_schema_provisioned = s.schema
        and (d.sgid = a.provisioning_company_id or user = s.schema or user in ('SYS','SYSTEM','APEX_040000')) and
      (user in ('SYS','SYSTEM', 'APEX_040000') or a.PROVISIONING_COMPANY_ID != 10)
/

comment on table APEX_WORKSPACE_CLICKS is 'Clicks in Application Express that are tracked by using APEX_UTIL.COUNT_CLICKS'
/

comment on column APEX_WORKSPACE_CLICKS.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_WORKSPACE_CLICKS.CATEGORY is 'Optional category used to track the click'
/

comment on column APEX_WORKSPACE_CLICKS.APEX_USER is 'Name of Application Express user that clicked'
/

comment on column APEX_WORKSPACE_CLICKS.CLICKDATE is 'Date of the recorded click'
/

comment on column APEX_WORKSPACE_CLICKS.CLICK_ID is 'Optional secondary ID to further track the click'
/

comment on column APEX_WORKSPACE_CLICKS.CLICKER_IP is 'The IP address of the clicker'
/

comment on column APEX_WORKSPACE_CLICKS.WORKSPACE_ID is 'Primary key that identifies the workspace'
/

