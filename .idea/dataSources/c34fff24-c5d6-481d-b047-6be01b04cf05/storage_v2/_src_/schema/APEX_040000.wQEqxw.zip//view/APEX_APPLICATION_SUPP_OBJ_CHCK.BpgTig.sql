create view APEX_APPLICATION_SUPP_OBJ_CHCK as
select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    c.ID                             check_id,
    c.NAME                           check_name,
    c.SEQUENCE                       check_sequence,
    --
    c.CHECK_TYPE                     check_type,
    c.CHECK_CONDITION                check_expression1,
    c.CHECK_CONDITION2               check_expression2,
    --
    --c.SUCCESS_MESSAGE                ,
    c.FAILURE_MESSAGE                error_message,
    --
    c.CONDITION_TYPE                 condition_type,
    c.CONDITION                      condition_expression1,
    c.CONDITION2                     condition_expression2,
    --
    c.LAST_UPDATED_BY                last_updated_by,
    c.LAST_UPDATED_ON                last_updated_on,
    c.CREATED_BY                     created_by,
    c.CREATED_ON                     created_on
from
     wwv_flow_install_checks c,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      f.id = c.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_APPLICATION_SUPP_OBJ_CHCK is 'Identifies the Supporting Object pre-installation checks to ensure the database is compatible with the objects to be installed'
/

comment on column APEX_APPLICATION_SUPP_OBJ_CHCK.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_SUPP_OBJ_CHCK.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_SUPP_OBJ_CHCK.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_SUPP_OBJ_CHCK.CHECK_ID is 'Specifies the ID for this validation.'
/

comment on column APEX_APPLICATION_SUPP_OBJ_CHCK.CHECK_NAME is 'Specifies the name for this validation.'
/

comment on column APEX_APPLICATION_SUPP_OBJ_CHCK.CHECK_SEQUENCE is 'Specifies the sequence for this validation. The sequence number determines the order of evaluation.'
/

comment on column APEX_APPLICATION_SUPP_OBJ_CHCK.CHECK_TYPE is 'Specifies the condition type that must be met during installation before installation scripts are run.'
/

comment on column APEX_APPLICATION_SUPP_OBJ_CHCK.CHECK_EXPRESSION1 is 'Use this attribute to conditionally control whether installation can continue. Values correspond to the specific condition type selected.'
/

comment on column APEX_APPLICATION_SUPP_OBJ_CHCK.CHECK_EXPRESSION2 is 'Use this attribute to conditionally control whether installation can continue. Values correspond to the specific condition type selected.'
/

comment on column APEX_APPLICATION_SUPP_OBJ_CHCK.ERROR_MESSAGE is 'Enter a message to be displayed when the conditions of this validation are not met.'
/

comment on column APEX_APPLICATION_SUPP_OBJ_CHCK.CONDITION_TYPE is 'Specifies a condition type from the list that conditionally controls whether this validation is performed.'
/

comment on column APEX_APPLICATION_SUPP_OBJ_CHCK.CONDITION_EXPRESSION1 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_SUPP_OBJ_CHCK.CONDITION_EXPRESSION2 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_SUPP_OBJ_CHCK.LAST_UPDATED_BY is 'APEX developer who made last update'
/

comment on column APEX_APPLICATION_SUPP_OBJ_CHCK.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_SUPP_OBJ_CHCK.CREATED_BY is 'Identifies the User Name of the APEX developer who created this check condition'
/

comment on column APEX_APPLICATION_SUPP_OBJ_CHCK.CREATED_ON is 'Identifies the date that this component was created'
/

