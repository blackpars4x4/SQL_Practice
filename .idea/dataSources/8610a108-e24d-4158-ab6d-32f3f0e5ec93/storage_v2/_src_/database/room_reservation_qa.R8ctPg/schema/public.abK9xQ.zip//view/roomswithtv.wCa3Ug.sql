create view roomswithtv (id, capacity, description, name, withtv, withwhiteboard, cluster_id, reservedfor_number) as
SELECT room.id,
       room.capacity,
       room.description,
       room.name,
       room.withtv,
       room.withwhiteboard,
       room.cluster_id,
       room.reservedfor_number
FROM room
WHERE room.withtv = true;

alter table roomswithtv
    owner to qa_user;

